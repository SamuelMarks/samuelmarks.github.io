"""
Sphinx Extension for ML-Switcheroo WASM Demo.
"""

from .wasm_demo import setup

__all__ = ["setup"]
