"""
Common shared utilities for Framework Adapters.
"""
