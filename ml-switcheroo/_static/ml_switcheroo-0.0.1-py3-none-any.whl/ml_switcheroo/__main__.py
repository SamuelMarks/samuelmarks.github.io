"""
Entry point for module execution (ml_switcheroo).
"""

import sys
from ml_switcheroo.cli.__main__ import main

if __name__ == "__main__":
  sys.exit(main())
