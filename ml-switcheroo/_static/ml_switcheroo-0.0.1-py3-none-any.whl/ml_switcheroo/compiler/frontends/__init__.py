"""
Compiler Frontends Package.

Contains parsers and lifters for converting source languages (SASS, RDNA, Python)
into the Logical Graph IR.
"""
