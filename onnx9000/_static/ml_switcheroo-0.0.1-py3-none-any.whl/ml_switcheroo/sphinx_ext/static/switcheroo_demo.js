/*
 * switcheroo_demo.js
 * Client-side controller for the WASM interactive demo.
 *
 * Capabilities:
 * - Pyodide Engine Management (WASM).
 * - CodeMirror Editor sync.
 * - Trace Graph Visualization.
 * - Weight Script Generation.
 * - TikZ/LaTeX Rendering Integration (TikZJax).
 * - Mermaid AST Visualization.
 * - **Time Travel Control**: Manages snapshot playback.
 * - **Configuration**: Passes user pipeline options to the engine.
 */

// Global State
let pyodide = null;
let srcEditor = null;
let tgtEditor = null;
let weightEditor = null;
let EXAMPLES = {};
let FW_TIERS = {};
let tikzLoaded = false;
let timeTravel = null; // Controller instance

// Default CDN fallback in case local assets are missing
const DEFAULT_TIKZJAX_URL = "https://tikzjax.com/v1/tikzjax.js";

/**
 * Python Script to be executed inside the Pyodide environment.
 * It imports the ml_switcheroo package, configures the ASTEngine,
 * runs the conversion, and generates weight scripts if applicable.
 *
 * Updates:
 * - Reads `js_enable_*` flags from globals for pipeline control.
 * - Passes flags to RuntimeConfig.
 */
const PYTHON_BRIDGE = `
import json
import traceback
import pathlib
import sys
from rich.console import Console
from ml_switcheroo.core.engine import ASTEngine
from ml_switcheroo.config import RuntimeConfig
from ml_switcheroo.semantics.manager import SemanticsManager
from ml_switcheroo.utils.console import set_console

# Setup Output Capture
process_log = Console(record=True, force_terminal=False, width=120)
set_console(process_log)

response = {}

try:
    # Initialize Semantics Singleton if needed to avoid re-parsing JSONs
    if 'GLOBAL_SEMANTICS' not in globals():
        GLOBAL_SEMANTICS = SemanticsManager()
    
    # Resolve flavors from JS globals
    src_flavour = js_src_flavour if 'js_src_flavour' in globals() and js_src_flavour else None
    tgt_flavour = js_tgt_flavour if 'js_tgt_flavour' in globals() and js_tgt_flavour else None

    # Determine execution config
    real_source = src_flavour if src_flavour else js_src_fw
    real_target = tgt_flavour if tgt_flavour else js_tgt_fw
    
    # Read optional flags (default False/True as set in JS)
    opt_graph = js_enable_graph_opt if 'js_enable_graph_opt' in globals() else False
    opt_imports = js_enable_import_fixer if 'js_enable_import_fixer' in globals() else True
    opt_sharding = js_enable_sharding if 'js_enable_sharding' in globals() else False

    config = RuntimeConfig(
        source_framework=js_src_fw,
        target_framework=js_tgt_fw,
        source_flavour=src_flavour,
        target_flavour=tgt_flavour,
        strict_mode=js_strict_mode,
        enable_graph_optimization=opt_graph,
        enable_import_fixer=opt_imports,
        enable_sharding=opt_sharding
    )
    
    # 1. Run Transpilation
    print(f"Running AST Engine ({real_source} -> {real_target})...")
    engine = ASTEngine(semantics=GLOBAL_SEMANTICS, config=config)
    result = engine.run(js_source_code)
    
    if result.success:
        print("Transpilation successful.")
    else:
        print("Transpilation failed with errors.")

    # 2. Run Weight Script Generator (If architecture detected)
    weight_script_code = ""
    
    # Fix: Block IR targets from generating weight scripts (Visual/Intermediate only)
    ir_targets = {'mlir', 'stablehlo', 'tikz', 'latex_dsl', 'html'}

    # We always attempt weight gen if successful, but fallback to empty string if no layers found
    if result.success and real_target not in ir_targets:
        try:
            # Virtual FS in Pyodide
            f_src = pathlib.Path("/tmp/src_model.py")
            f_src.write_text(js_source_code, encoding="utf-8")
            f_out = pathlib.Path("/tmp/migration_script.py")
            
            from ml_switcheroo.cli.handlers.convert_weights import WeightScriptGenerator
            
            wgen = WeightScriptGenerator(GLOBAL_SEMANTICS, config)
            success = wgen.generate(f_src, f_out)
            
            if success and f_out.exists():
                weight_script_code = f_out.read_text(encoding="utf-8")
            else:
                pass 
                # Silent fail typical for non-architecture code
        except Exception as e:
            print(f"Weight Gen Error: {e}")

    # Build Response using Pydantic dumps where available or manual dict
    response = {
        "code": result.code,
        "logs": process_log.export_text(),
        "is_success": result.success,
        "errors": result.errors,
        "trace_events": result.trace_events,
        "weight_script": weight_script_code
    }
except Exception as e:
    err_str = traceback.format_exc()
    response = {
        "code": "",
        "logs": f"{process_log.export_text()}\\nCRITICAL PYTHON ERROR: {str(e)}\\n{err_str}",
        "is_success": False,
        "errors": [str(e)],
        "trace_events": [],
        "weight_script": ""
    }

json_output = json.dumps(response)
`;

/**
 * Initializes the Python environment (Pyodide) and installs dependencies.
 * Triggered by the "Initialize Engine" button.
 */
async function initEngine() {
    const rootEl = document.getElementById("switcheroo-wasm-root");
    const statusEl = document.getElementById("engine-status");
    const btnLoad = document.getElementById("btn-load-engine");
    const splashEl = document.getElementById("demo-splash");
    const interfaceEl = document.getElementById("demo-interface");
    const wheelName = (rootEl && rootEl.dataset.wheel) ? rootEl.dataset.wheel : "ml_switcheroo-0.0.1-py3-none-any.whl";

    statusEl.innerText = "Downloading...";
    statusEl.className = "status-badge status-loading";
    btnLoad.disabled = true;

    try {
        // 1. Load Pyodide
        if (!window.loadPyodide) await loadScript("https://cdn.jsdelivr.net/pyodide/v0.29.0/full/pyodide.js");
        if (!pyodide) pyodide = await loadPyodide();

        // 2. Load TikZJax (Lazy with Smart Path Resolution)
        if (!tikzLoaded) {
            let urlToLoad = DEFAULT_TIKZJAX_URL;
            if (window.DOCUMENTATION_OPTIONS && window.DOCUMENTATION_OPTIONS.URL_ROOT) {
                const root = window.DOCUMENTATION_OPTIONS.URL_ROOT;
                const safeRoot = root.endsWith('/') ? root : root + '/';
                urlToLoad = `${safeRoot}_static/tikzjax/tikzjax.js`;
            } else if (window.TIKZJAX_URL) {
                urlToLoad = window.TIKZJAX_URL;
            }

            try {
                await loadScript(urlToLoad);
                tikzLoaded = true;
            } catch (tiErr) {
                try {
                    await loadScript(DEFAULT_TIKZJAX_URL);
                    tikzLoaded = true;
                } catch (cdnErr) {
                    tikzLoaded = false;
                }
            }
        }

        // 3. Check for Engine Install
        const isInstalled = pyodide.runPython(`
import importlib.util
importlib.util.find_spec("ml_switcheroo") is not None
        `);

        if (!isInstalled) {
            statusEl.innerText = "Fetching Requirements...";
            await pyodide.loadPackage("micropip");
            const micropip = pyodide.pyimport("micropip");

            // Attempt to load local requirements or fallback to minimal set
            try {
                const reqRes = await fetch("_static/requirements.txt");
                if (reqRes.ok) {
                    const reqText = await reqRes.text();
                    const reqs = reqText.split('\n').map(l => l.trim()).filter(l => l && !l.startsWith('#'));
                    await micropip.install("numpy");
                    if (reqs.length > 0) await micropip.install(reqs);
                } else {
                    await micropip.install(["numpy", "pydantic", "rich", "libcst"]);
                }
            } catch (e) {
                await micropip.install(["numpy", "pydantic", "rich", "libcst"]);
            }

            statusEl.innerText = "Installing Engine...";
            const wheelUrl = new URL(`_static/${wheelName}`, window.location.href).href;
            await micropip.install(wheelUrl);
        }

        // 4. UI Transition
        splashEl.style.display = "none";
        interfaceEl.style.display = "block";
        initEditors();

        if (window.SWITCHEROO_PRELOADED_EXAMPLES) EXAMPLES = window.SWITCHEROO_PRELOADED_EXAMPLES;
        if (window.SWITCHEROO_FRAMEWORK_TIERS) FW_TIERS = window.SWITCHEROO_FRAMEWORK_TIERS;

        initExampleSelector();
        initFrameworkListeners();
        updateRenderTabVisibility();

        // Initialize TimeTravel Logic with callbacks
        if (window.TimeTravelController) {
            timeTravel = new window.TimeTravelController({
                onUpdateCode: (code) => {
                    if (tgtEditor) {
                        tgtEditor.setValue(code);
                        // Refresh wrapper state for visual update
                        let mode = "python";
                        if (document.getElementById("select-tgt").value === 'html') mode = "htmlmixed";
                        tgtEditor.setOption("mode", mode);
                    }
                },
                onUpdateGraph: (mermaidStr) => renderMermaid(mermaidStr)
            });
        }

        statusEl.innerText = "Ready";
        statusEl.className = "status-badge status-ready";
        document.getElementById("btn-convert").disabled = false;

        // Initialize Mermaid config if not already done
        if (typeof mermaid !== "undefined") {
            mermaid.initialize({ startOnLoad: false, theme: 'neutral', securityLevel: 'loose' });
        }

    } catch (err) {
        console.error(err);
        statusEl.innerText = "Load Failed";
        statusEl.className = "status-badge status-error";
        btnLoad.disabled = false;
    }
}

/**
 * Initializes CodeMirror instances for Source, Target, and Weights.
 */
function initEditors() {
    if (srcEditor) {
        srcEditor.refresh();
        if (tgtEditor) tgtEditor.refresh();
        if (weightEditor) weightEditor.refresh();
        return;
    }
    const opts = { mode: "python", lineNumbers: true, viewportMargin: Infinity, theme: "default" };
    srcEditor = CodeMirror.fromTextArea(document.getElementById("code-source"), { ...opts, readOnly: false });
    tgtEditor = CodeMirror.fromTextArea(document.getElementById("code-target"), { ...opts, readOnly: true });

    // Initialize Weight Script Editor
    const weightEl = document.getElementById("code-weights");
    if (weightEl) {
        weightEditor = CodeMirror.fromTextArea(weightEl, { ...opts, readOnly: true });
    }
}

/**
 * Populates the Example dropdown from the loaded registry.
 */
function initExampleSelector() {
    const sel = document.getElementById("select-example");
    if (!sel) return;
    sel.innerHTML = '<option value="" disabled>-- Select a Pattern --</option>';

    const sortedKeys = Object.keys(EXAMPLES).sort();
    for (const key of sortedKeys) {
        const opt = document.createElement("option");
        opt.value = key;
        opt.innerText = EXAMPLES[key].label;
        sel.appendChild(opt);
    }
    sel.onchange = (e) => loadExample(e.target.value);

    // Auto-select a neural example if possible for better first impression
    if (sortedKeys.length > 0) {
       const preferred = sortedKeys.find(k => k.includes("torch") && k.includes("neural"));
       const defKey = preferred || sortedKeys[0];
       sel.value = defKey;
       loadExample(defKey);
    }
}

/**
 * Attaches event listeners for framework dropdowns logic handling.
 */
function initFrameworkListeners() {
    const handler = (type) => {
        const sel = document.getElementById(`select-${type}`);
        const region = document.getElementById(`${type}-flavour-region`);

        if (region) {
             const hasFlavours = ['jax', 'flax'].includes(sel.value);
             region.style.display = hasFlavours ? 'inline-block' : 'none';
        }
        updateRenderTabVisibility();
    };

    document.getElementById("select-src").addEventListener("change", () => handler('src'));
    document.getElementById("select-tgt").addEventListener("change", () => handler('tgt'));
    updateRenderTabVisibility();

    // -- Tab Switching Listener for Refreshing Editors --
    document.querySelectorAll('input[name="wm-tabs"]').forEach(radio => {
        radio.addEventListener('change', (e) => {
            if (e.target.id === 'tab-weights' && weightEditor) {
                // Short timeout to allow CSS display transition so CodeMirror calculates size correctly
                setTimeout(() => weightEditor.refresh(), 20);
            }
        });
    });
}

function updateRenderTabVisibility() {
    const srcFw = document.getElementById("select-src").value;
    const tgtFw = document.getElementById("select-tgt").value;

    const isVisual = (srcFw === 'tikz' || tgtFw === 'tikz' || srcFw === 'html' || tgtFw === 'html');
    const tabLabel = document.getElementById("label-tab-render");
    const tabInput = document.getElementById("tab-render");

    if (tabLabel) {
        if (isVisual) {
            tabLabel.style.display = "inline-flex";
        } else {
            tabLabel.style.display = "none";
            if (tabInput && tabInput.checked) {
                document.getElementById("tab-trace").checked = true;
            }
        }
    }
}

function loadExample(key) {
    const ex = EXAMPLES[key];
    if (!ex) return;
    srcEditor.setValue(ex.code);
    tgtEditor.setValue("");

    if (weightEditor) weightEditor.setValue("");

    setSelectValue(document.getElementById("select-src"), ex.srcFw);
    const tgtSelect = document.getElementById("select-tgt");
    for (let opt of tgtSelect.options) opt.disabled = false;
    setSelectValue(tgtSelect, ex.tgtFw);

    document.getElementById("select-src").dispatchEvent(new Event('change'));
    document.getElementById("select-tgt").dispatchEvent(new Event('change'));

    if (ex.srcFlavour) setSelectValue(document.getElementById("src-flavour"), ex.srcFlavour);
    if (ex.tgtFlavour) setSelectValue(document.getElementById("tgt-flavour"), ex.tgtFlavour);
}

function setSelectValue(el, val) {
    if (!el) return;
    for (let i=0; i<el.options.length; i++) {
        if (el.options[i].value === val) {
            el.selectedIndex = i;
            break;
        }
    }
}

function swapContext() {
    const s = document.getElementById("select-src");
    const t = document.getElementById("select-tgt");
    [s.value, t.value] = [t.value, s.value];

    s.dispatchEvent(new Event("change"));
    t.dispatchEvent(new Event("change"));

    const sf = document.getElementById("src-flavour");
    const tf = document.getElementById("tgt-flavour");
    if (sf && tf) {
        const temp = sf.value;
        sf.value = tf.value;
        tf.value = temp;
        sf.dispatchEvent(new Event("change"));
        tf.dispatchEvent(new Event("change"));
    }

    const tmp = srcEditor.getValue();
    srcEditor.setValue(tgtEditor.getValue());
    tgtEditor.setValue(tmp);
}

/**
 * Highlights a line in the source editor when hovering over trace components.
 */
function updateLineHighlight(event, hover) {
    if (!srcEditor || !event.lineno) return;
    const ln = event.lineno - 1;
    const method = hover ? "addLineClass" : "removeLineClass";
    srcEditor[method](ln, "background", "cm-trace-highlight");
}

function toggleRetroMode() {
    document.body.classList.toggle("crt-mode");
}

function loadScript(src) {
    return new Promise((res, rej) => {
        const s = document.createElement('script');
        s.src = src;
        s.async = true;
        s.onload = res;
        s.onerror = rej;
        document.head.appendChild(s);
    });
}

/**
 * Renders a Mermaid graph into the AST visualization tab.
 * Handles Mermaid v10+ async rendering properly.
 *
 * @param {string} graphDef - The Mermaid graph definition string (e.g. "graph TD...").
 */
async function renderMermaid(graphDef) {
    const element = document.getElementById('ast-mermaid-target');
    if (!element) return;

    if (!graphDef || graphDef.trim() === '') {
        element.innerHTML = '<em style="color:#999">No graph data available.</em>';
        return;
    }

    // Set loading state
    element.innerHTML = '<div style="padding:20px; color:#666">Rendered Graph</div>';

    try {
        if (typeof mermaid === "undefined") {
            element.innerText = "Mermaid library not loaded.";
            return;
        }

        // Generate unique ID for SVG isolation to prevent conflicts
        const uniqueId = `mermaid-graph-${Date.now()}`;

        // Attempt Render
        // API: mermaid.render(id, text) -> { svg: string } in v10
        const result = await mermaid.render(uniqueId, graphDef);
        element.innerHTML = result.svg;

    } catch (e) {
        console.error("Mermaid Render Fail", e);
        element.innerHTML = `<div style="color:red; padding:10px; border:1px solid red;">
            <strong>Graph Render Error:</strong><br/>
            ${e.message || String(e)}
        </div>`;
    }
}

function renderHtmlDSL(htmlCode) {
    const container = document.getElementById("tikz-output-container");
    if (!container) return;

    // Use iframe for style isolation
    container.innerHTML = '<iframe style="width:100%; height:100%; min-height:400px; border:none;"></iframe>';
    const iframe = container.querySelector("iframe");
    const doc = iframe.contentDocument || iframe.contentWindow.document;
    doc.open();
    doc.write(htmlCode);
    doc.close();
}

function renderTikZ(tikzCode) {
    const container = document.getElementById("tikz-output-container");
    if (!container) return;
    // Basic injection for TikZJax to find
    container.innerHTML = `<script type="text/tikz">${tikzCode}</script>`;
    // Force re-scan if library is loaded
    if (window.tikzjax) {
         // Some versions of tikzjax need explicit trigger or just handle DOM mutations.
         // Pass for now, assuming DOM mutation observer in lib or simple refresh.
    }
}

/**
 * Executes the main translation logic in Pyodide.
 */
async function runTranspilation() {
    if (!pyodide || !srcEditor) return;
    const consoleEl = document.getElementById("console-output");
    const btn = document.getElementById("btn-convert");
    const srcCode = srcEditor.getValue();

    if (!srcCode.trim()) {
        consoleEl.innerText = "Source code is empty.";
        return;
    }

    btn.disabled = true;
    btn.innerText = "Running...";
    consoleEl.innerText = "Processing...";

    // Gather Inputs
    const srcFw = document.getElementById("select-src").value;
    const tgtFw = document.getElementById("select-tgt").value;
    let srcFlav = "", tgtFlav = "";
    const srcReg = document.getElementById("src-flavour-region");
    const tgtReg = document.getElementById("tgt-flavour-region");
    if(srcReg && srcReg.style.display !== 'none') srcFlav = document.getElementById("src-flavour").value;
    if(tgtReg && tgtReg.style.display !== 'none') tgtFlav = document.getElementById("tgt-flavour").value;

    // Gather Pipeline Options
    const optStrictMode = !!document.getElementById("chk-strict-mode").checked;
    const optSharding = !!document.getElementById("chk-enable-sharding").checked;
    const optGraph = !!document.getElementById("chk-opt-graph").checked;
    const optImports = !!document.getElementById("chk-opt-imports").checked;

    try {
        pyodide.globals.set("js_source_code", srcCode);
        pyodide.globals.set("js_src_fw", srcFw);
        pyodide.globals.set("js_tgt_fw", tgtFw);
        pyodide.globals.set("js_src_flavour", srcFlav);
        pyodide.globals.set("js_tgt_flavour", tgtFlav);
        pyodide.globals.set("js_strict_mode", optStrictMode);
    pyodide.globals.set("js_enable_sharding", optSharding);
        
        // Pass pipeline flags
        pyodide.globals.set("js_enable_graph_opt", optGraph);
        pyodide.globals.set("js_enable_import_fixer", optImports);

        // Execute Python
        await pyodide.runPythonAsync(PYTHON_BRIDGE);

        const jsonRaw = pyodide.globals.get("json_output");
        const result = JSON.parse(jsonRaw);

        tgtEditor.setValue(result.code);

        // Update Weight Script editor
        if (weightEditor) {
            if (result.weight_script) {
                weightEditor.setValue(result.weight_script);
            } else {
                weightEditor.setValue("# No weight script generated.");
            }
        }

        // Update syntax highlighting based on target framework
        if (tgtFw === 'html') {
             tgtEditor.setOption("mode", "htmlmixed");
        } else {
             tgtEditor.setOption("mode", "python");
        }

        // Force refresh to ensure highlighting applies
        setTimeout(() => {
            tgtEditor.refresh();
            if (weightEditor) weightEditor.refresh();
        }, 50);

        // Manage Weight Tab Visibility
        const weightLabel = document.getElementById("label-tab-weights");
        if (weightLabel) {
            // Reduced threshold to 20 chars to catch short valid scripts or errors
            if (result.weight_script && result.weight_script.length > 20) {
                weightLabel.style.color = "#2196f3"; // Visual cue
                weightLabel.style.display = "inline-flex"; // Show tab
            } else {
                weightLabel.style.display = "none"; // Hide tab
                // If user was on the tab, switch them back to trace
                if (document.getElementById("tab-weights") && document.getElementById("tab-weights").checked) {
                    document.getElementById("tab-trace").checked = true;
                }
            }
        }

        if (result.is_success) {
             consoleEl.innerText = `✅ Success!\n\n--- Engine Logs ---\n${result.logs}`;

             if (tgtFw === 'tikz' || srcFw === 'tikz') {
                 document.getElementById("tab-render").checked = true;
                 setTimeout(() => renderTikZ(result.code), 150); 
             } else if (tgtFw === 'html' || srcFw === 'html') {
                 document.getElementById("tab-render").checked = true;
                 renderHtmlDSL(result.code);
             }

        } else {
             consoleEl.innerText = `❌ Error\n\n${result.logs}`;
        }

        // Trace Handling (Viz)
        if (result.trace_events) {
             if (window.TraceGraph) {
                 // Render the timeline list
                 new window.TraceGraph('trace-visualizer', updateLineHighlight).render(result.trace_events);
             }
             
             // Initialize Time Travel Controller
             if (timeTravel) {
                 timeTravel.loadEvents(result.trace_events);
             }
             
             // Initial Graph Render (Final state if available, or first valid snapshot?)
             // TimeTravel seek to last does this automatically now. 
        }
    } catch (err) {
        console.error("Transpilation JS Error", err);
        consoleEl.innerText += `\n❌ JS Runtime Error:\n${err}`;
    } finally {
        btn.disabled = false;
        btn.innerText = "Run Translation";
    }
}

document.addEventListener("DOMContentLoaded", () => {
    document.getElementById("btn-load-engine").addEventListener("click", initEngine);
    document.getElementById("btn-convert").addEventListener("click", runTranspilation);
    document.getElementById("btn-swap").addEventListener("click", swapContext);
    document.getElementById("btn-retro").addEventListener("click", toggleRetroMode);

    document.getElementById("btn-ast-prev")?.addEventListener("click", (e) => {
        // Legacy buttons support if timeline not used
    });

    document.getElementById("btn-ast-next")?.addEventListener("click", (e) => {
    });
});

// --- Material 3 Stepper Logic ---
function switchStep(stepId) {
    // Hide all contents
    document.querySelectorAll('.m3-step-content').forEach(el => {
        el.style.display = 'none';
        el.classList.remove('active');
    });
    
    // Update navigation styles
    document.querySelectorAll('.m3-step').forEach(el => {
        el.classList.remove('active');
        
        // Mark as completed if it's before the current step
        const currentStepNum = parseInt(stepId.replace('step-', ''));
        const thisStepNum = parseInt(el.getAttribute('data-target').replace('step-', ''));
        
        if (thisStepNum < currentStepNum) {
            el.classList.add('completed');
        } else {
            el.classList.remove('completed');
        }
    });
    
    // Show current content
    const targetEl = document.getElementById(stepId);
    if (targetEl) {
        targetEl.style.display = 'block';
        targetEl.classList.add('active');
    }
    
    // Activate nav item
    const navEl = document.querySelector(`.m3-step[data-target="${stepId}"]`);
    if (navEl) {
        navEl.classList.add('active');
    }
}

document.addEventListener("DOMContentLoaded", () => {
    // Nav Click
    document.querySelectorAll('.m3-step').forEach(el => {
        el.addEventListener('click', () => {
            switchStep(el.getAttribute('data-target'));
        });
    });

    // Step 0 -> Step 1
    const btnNextStep1 = document.getElementById('btn-next-step1');
    if (btnNextStep1) {
        btnNextStep1.addEventListener('click', () => {
            // Copy right hand side of Step 0 to left hand side of Step 1
            const tgtCode = window.tgtEditor ? window.tgtEditor.getValue() : document.getElementById('code-target').value;
            const step1Src = document.getElementById('code-step1-source');
            if (step1Src) {
                step1Src.value = tgtCode || "# Run translation in Step 0 first to see output here.";
            }
            
            // Mock ONNX generation
            const step1Tgt = document.getElementById('code-step1-target');
            if (step1Tgt) {
                step1Tgt.value = "ir_version: 8\nproducer_name: \"ml-switcheroo-onnx9000\"\ngraph {\n  node {\n    input: \"x\"\n    output: \"y\"\n    op_type: \"Abs\"\n  }\n  name: \"main_graph\"\n  input {\n    name: \"x\"\n    type {\n      tensor_type {\n        elem_type: 1\n        shape {\n          dim {\n            dim_value: 1\n          }\n        }\n      }\n    }\n  }\n  output {\n    name: \"y\"\n    type {\n      tensor_type {\n        elem_type: 1\n        shape {\n          dim {\n            dim_value: 1\n          }\n        }\n      }\n    }\n  }\n}";
            }
            
            switchStep('step-1');
        });
    }

    // Step 1 -> Step 2
    const btnNextStep2 = document.getElementById('btn-next-step2');
    if (btnNextStep2) {
        btnNextStep2.addEventListener('click', () => {
            switchStep('step-2');
            
            // Simulate Compilation Log
            const logEl = document.getElementById('compile-log');
            if (logEl) {
                logEl.innerHTML = "[INFO] Starting onnx9000 transpilation...\n";
                let step = 0;
                const messages = [
                    "[INFO] Parsing ONNX graph 'main_graph'...",
                    "[INFO] Validating graph topology...",
                    "[INFO] Performing Liveness Analysis...",
                    "[INFO] Allocating static memory arena (Size: 1.2 MB)...",
                    "[INFO] Generating C++23 Forward Pass...",
                    "[INFO] Generating C++23 Backward Pass (Autograd)...",
                    "[INFO] Compiling C++ to WebAssembly via Emscripten...",
                    "[INFO] Optimizing WASM binary (SIMD enabled)...",
                    "[SUCCESS] WASM compilation complete! Binary size: 45KB."
                ];
                
                const interval = setInterval(() => {
                    if (step < messages.length) {
                        logEl.innerHTML += messages[step] + "\n";
                        logEl.scrollTop = logEl.scrollHeight;
                        step++;
                    } else {
                        clearInterval(interval);
                    }
                }, 400);
            }
        });
    }

    // Step 2 -> Step 3
    const btnNextStep3 = document.getElementById('btn-next-step3');
    if (btnNextStep3) {
        btnNextStep3.addEventListener('click', () => {
            switchStep('step-3');
            
            // Update Live UI based on selection
            const execType = document.getElementById('select-execution').value;
            const modality = document.getElementById('select-modality').value;
            
            const liveUi = document.getElementById('live-system-ui');
            if (liveUi) {
                if (execType === 'download') {
                    liveUi.innerHTML = `
                        <div style="font-size: 48px; margin-bottom: 15px;">💾</div>
                        <h3 style="margin: 0 0 10px 0;">Ready for Download</h3>
                        <p style="color: #666; margin: 0;">Your ${modality} model is compiled and ready to be served on your PC/Servers.</p>
                        <div style="margin-top: 20px;">
                            <button class="md-btn md-btn-accent">Download WASM Bundle (.zip)</button>
                        </div>
                    `;
                } else {
                    liveUi.innerHTML = `
                        <div style="font-size: 48px; margin-bottom: 15px;">🚀</div>
                        <h3 style="margin: 0 0 10px 0;">Model Ready</h3>
                        <p style="color: #666; margin: 0;">Training and serving locally in your browser via WebAssembly (${modality} modality).</p>
                        <div style="margin-top: 20px; display:flex; gap: 10px;">
                            <button class="md-btn" style="background: white; border: 1px solid #ccc; color: #333;">Interact with Model</button>
                            <button class="md-btn md-btn-accent">Visualize Metrics</button>
                        </div>
                    `;
                }
            }
        });
    }
});
