"""Analysis module."""
