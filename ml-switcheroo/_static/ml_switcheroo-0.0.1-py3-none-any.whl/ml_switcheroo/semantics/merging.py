"""
Merging Logic for Semantic Knowledge Base.

This module handles the aggregation of disparate knowledge sources (Specs, Snapshots)
into the central SemanticsManager. It resolves conflicts based on Tier Precedence
and merges framework-specific configurations.

Handles:
- Merging Specification Tiers (Math, Neural, Extras).
- Merging Snapshot Overlays (Framework mappings).
- Conflict resolution and prioritization (Warning vs Silencing).
- Merging Framework Traits and Import Maps.
"""

import warnings
from typing import Dict, Any

from pydantic import ValidationError

from ml_switcheroo.enums import SemanticTier
from ml_switcheroo.semantics.schema import OpDefinition

# Hierarchy of tier importance for overwriting checks
# Higher numbers mean higher importance (harder to overwrite the Tier Origin)
# EXTRAS is lowest (1) to ensure that if a Neural/Math op is patched in Extras,
# it retains its original high-value semantic tag (e.g. Neural for state injection).
TIER_PRECEDENCE = {
  SemanticTier.NEURAL.value: 3,
  SemanticTier.ARRAY_API.value: 2,
  SemanticTier.NEURAL_OPS.value: 2,
  SemanticTier.EXTRAS.value: 1,
}


def infer_tier_from_priority(priority: int) -> SemanticTier:
  """
  Maps a loading priority integer to a Semantic Tier.

  Args:
      priority (int): Loading order (10=Math, 20=Neural, etc).

  Returns:
      SemanticTier: The inferred tier enum.
  """
  if priority == 10:
    return SemanticTier.ARRAY_API
  if priority == 20:
    return SemanticTier.NEURAL
  return SemanticTier.EXTRAS


def merge_imports(master_import_data: Dict[str, Dict], new_imports: Dict[str, Any]) -> None:
  """
  Merges new import definitions (from __imports__ block) into the master dictionary.
  Updates in-place.

  Args:
      master_import_data: The central import dictionary.
      new_imports: Dictionary of new import rules to merge.
  """
  for src_mod, details in new_imports.items():
    if src_mod not in master_import_data:
      master_import_data[src_mod] = details
    else:
      existing_variants = master_import_data[src_mod].get("variants", {})
      new_variants = details.get("variants", {})
      existing_variants.update(new_variants)
      master_import_data[src_mod]["variants"] = existing_variants


def merge_frameworks(master_configs: Dict[str, Dict], new_configs: Dict[str, Any]) -> None:
  """
  Merges new framework configurations (from __frameworks__ block) into the master.
  Updates in-place.

  Args:
      master_configs: The central framework definitions dictionary.
      new_configs: Dictionary of framework traits to merge.
  """
  for fw_name, traits in new_configs.items():
    if fw_name not in master_configs:
      master_configs[fw_name] = traits
    else:
      current = master_configs[fw_name]
      if "alias" in traits and "alias" in current:
        current["alias"].update(traits["alias"])
        traits_copy = traits.copy()
        del traits_copy["alias"]
        current.update(traits_copy)
      elif "traits" in traits:
        # If JSON redefined traits, simple merge/overwrite
        current["traits"] = traits["traits"]
      else:
        current.update(traits)


def merge_tier_data(
  data: Dict[str, Dict],
  key_origins: Dict[str, str],
  import_data: Dict[str, Dict],
  framework_configs: Dict[str, Dict],
  new_content: Dict[str, Any],
  tier: SemanticTier,
) -> None:
  """
  Merges content from a Specification file (hub) into the manager state.

  Handles precedence logic: Neural definitions overwrite Array definitions silently
  for upgrades. Duplicate definitions at the same tier level with conflicting signatures
  trigger warnings.

  Args:
      data: Master dictionary of operations.
      key_origins: Dict tracking where an op was defined (Math vs Neural).
      import_data: Master dictionary of import mappings.
      framework_configs: Master dictionary of framework traits.
      new_content: The JSON content being loaded.
      tier: The Semantic Tier of the file being loaded.
  """
  data_copy = new_content.copy()

  if "__imports__" in data_copy:
    merge_imports(import_data, data_copy.pop("__imports__"))

  if "__frameworks__" in data_copy:
    merge_frameworks(framework_configs, data_copy.pop("__frameworks__"))

  for op_name, details in data_copy.items():
    should_update_origin = True

    try:
      validated_op = OpDefinition.model_validate(details)
      stored_dict = validated_op.model_dump(by_alias=True, exclude_unset=True)

      if op_name in data:
        # Idempotency Check: If the new definition is identical to existing, skip
        if data[op_name] == stored_dict:
          continue

        existing_entry = data[op_name]
        prev_tier_val = key_origins.get(op_name, "unknown")

        # Determine precedence
        prev_prec = TIER_PRECEDENCE.get(prev_tier_val, 0)
        curr_prec = TIER_PRECEDENCE.get(tier.value, 0)

        # Downgrade Protection: Don't let low-priority spec overwrite high-priority origin tag
        if curr_prec < prev_prec:
          should_update_origin = False

        # Intelligent Merging:
        # If we are in the same tier, or upgrading, we should try to preserve existing variants
        # unless the new spec is radically different.
        if curr_prec >= prev_prec:
          existing_variants = existing_entry.get("variants", {})
          new_variants = stored_dict.get("variants", {})

          # Merge variants: New variants overwrite existing ones for the same framework key
          existing_variants.update(new_variants)
          stored_dict["variants"] = existing_variants

          # Warning Logic:
          # Warn only if a meaningful conflict (signature mismatch) exists at the same tier.
          # Upgrades (e.g. Array->Neural) are silent.
          # Same-Tier with identical args (e.g. doc-only update) are silent.
          if tier != SemanticTier.EXTRAS and should_update_origin:
            if curr_prec == prev_prec:
              old_args = existing_entry.get("std_args", [])
              new_args = stored_dict.get("std_args", [])
              if old_args != new_args:
                warnings.warn(
                  f"Conflict detected for '{op_name}': Signature mismatch within '{tier.value}'. Overwriting.",
                  UserWarning,
                )

      # Merge dictionaries (Overwrite properties with new spec, but variants are merged above)
      data[op_name] = stored_dict

      # Only update the Tier Origin if precedence allows
      if should_update_origin:
        key_origins[op_name] = tier.value

    except ValidationError as e:
      print(f"⚠️  Skipping invalid definition '{op_name}' in {tier.value}: {e}")
      continue


def merge_overlay_data(
  data: Dict[str, Dict],
  key_origins: Dict[str, str],
  import_data: Dict[str, Dict],
  framework_configs: Dict[str, Dict],
  test_templates: Dict[str, Dict],
  content: Dict[str, Any],
  filename: str,
) -> None:
  """
  Merges a mapping overlay file (snapshot) into the main data.

  Snapshots contain framework-specific implementation overlays ("Spokes")
  that attach to the Abstract Operations ("Hub").

  Args:
      data: Master dictionary of operations.
      key_origins: Dict tracking tier origins.
      import_data: Master dictionary of import mappings.
      framework_configs: Master dictionary of framework traits.
      test_templates: Master dictionary of testing templates.
      content: The JSON content of the snapshot file.
      filename: Filename for metadata inference if needed.
  """
  target_fw = content.get("__framework__")

  if not target_fw:
    # Fallback: try to guess from filename 'torch_v1.0.json' -> 'torch'
    parts = filename.split("_v")
    if len(parts) > 1:
      target_fw = parts[0]
    else:
      return  # Cannot determine target framework, skip

  # 1. Merge Template Config if present
  if "templates" in content:
    test_templates[target_fw] = content["templates"]

  # 2. Merge Framework Traits (Aliases)
  if "framework" in content:
    if target_fw not in framework_configs:
      framework_configs[target_fw] = content["framework"]
    else:
      framework_configs[target_fw].update(content["framework"])

  # 3. Merge Import Maps
  if "imports" in content:
    # Handle inversion: Snapshot has { "torch.nn": { "root": "flax", ... } }
    # Manager structure is { "torch.nn": { "variants": { "jax": { ... } } } }
    for src_mod, details in content["imports"].items():
      if src_mod not in import_data:
        import_data[src_mod] = {"variants": {}}

      import_data[src_mod]["variants"][target_fw] = details

  # 4. Merge Mappings
  mappings = content.get("mappings", {})
  for op_name, implementation in mappings.items():
    # A. Check if Op exists in Spec
    if op_name not in data:
      # If not in spec, create a skeleton description.
      data[op_name] = {
        "description": f"Auto-generated from {filename}",
        "std_args": [],  # Unknown if not in Spec
        "variants": {},
      }
      # Heuristic Tier Detection for orphan mappings
      if op_name not in key_origins:
        if op_name and op_name[0].isupper():
          key_origins[op_name] = SemanticTier.NEURAL.value
        else:
          key_origins[op_name] = SemanticTier.EXTRAS.value

    # B. Ensure 'variants' dict exists
    if "variants" not in data[op_name]:
      data[op_name]["variants"] = {}

    # C. Inject Variant
    if implementation is None:
      data[op_name]["variants"][target_fw] = None
    else:
      if target_fw not in data[op_name]["variants"]:
        data[op_name]["variants"][target_fw] = {}

      current_variant = data[op_name]["variants"][target_fw]
      # Handle case where current_variant might be None (from previous explicit disable)
      if current_variant is None:
        current_variant = {}
        data[op_name]["variants"][target_fw] = current_variant

      current_variant.update(implementation)
