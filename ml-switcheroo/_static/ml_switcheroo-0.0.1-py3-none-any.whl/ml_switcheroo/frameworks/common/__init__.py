"""
Common utilities and shared logic for Framework Adapters.
"""
