"""
ml-switcheroo Package.

A deterministic AST transpiler for converting Deep Learning models between
frameworks (PyTorch -> JAX).
"""

__version__ = "0.0.1"
